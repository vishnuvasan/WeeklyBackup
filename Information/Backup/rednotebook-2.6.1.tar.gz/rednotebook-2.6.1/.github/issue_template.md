### Versions

RedNotebook version (make sure you have the latest version): 

Operating system and version:

### Expected behavior

### Actual behavior

### Steps to reproduce the behavior

### Log output when reproducing behavior
($HOME/.rednotebook/rednotebook.log or C:\Users\<username>\.rednotebook.log)
